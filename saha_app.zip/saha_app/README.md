# Meydan Elektrik — Saha Uygulaması

## Klasör Yapısı

```
saha_app/
├── saha_app.py          ← Flask uygulaması (bu dosya)
├── requirements.txt     ← Python bağımlılıkları
├── Procfile             ← Railway başlatma komutu
└── saha_templates/      ← HTML şablonları
    ├── base.html
    ├── login.html
    ├── anasayfa.html
    ├── yeni_servis.html
    ├── servislerim.html
    ├── yeni_teklif.html
    ├── tekliflerim.html
    └── musteri_ara.html
```

## Railway'e Deploy

1. GitHub'da yeni repo oluştur: `meydan-saha-app`
2. Bu dosyaları repoya yükle (klasör yapısını koru)
3. Railway'de **New Project → Deploy from GitHub** → bu repoyu seç
4. Environment Variables ekle:
   - `MYSQL_PUBLIC_URL` → mevcut Railway DB bağlantısından kopyala (aynı DB!)
   - `SECRET_KEY` → rastgele bir string (Ör: `saha_gizli_anahtar_2025`)
5. Deploy tamamlandığında Railway sana URL verecek (Ör: `meydan-saha.up.railway.app`)

## Özellikler

- ✅ Login (mevcut personel tablosundan, rol=saha)
- ✅ Ana Sayfa — bugün/toplam servis istatistikleri
- ✅ Yeni Servis — müşteri seç, tarih/saat, açıklama, malzeme listesi
- ✅ Servislerim — tüm servisler + Düzeltme Talebi butonu
- ✅ Yeni Teklif — manuel kalem girişi, otomatik KDV hesaplama
- ✅ Tekliflerim — taslak/iletildi durumlarıyla liste
- ✅ Müşteri Ara — isim/şirket/telefon ile arama + tek tıkla arama

## Notlar

- Aynı DB kullanılır, ayrı tablo gerekmez
- `duzeltme_talepleri` tablosu zaten mevcut
- Saha ekibinin rolü `saha` — admin paneline erişemez
- Mobil-first tasarım, PWA benzeri bottom navigation
